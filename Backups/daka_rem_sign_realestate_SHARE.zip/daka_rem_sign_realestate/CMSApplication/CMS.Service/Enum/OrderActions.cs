﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CMS.Service.Enum
{
    public enum OrderActions
    {
        ChangeStatus =1,
        UploadFile = 2,
        Comment =3,
        UpdatePercent =4
    }
}
